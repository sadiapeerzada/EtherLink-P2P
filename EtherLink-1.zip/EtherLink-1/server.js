const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 3000 });
const rooms = {};

wss.on('connection', ws=>{
    ws.on('message', msg=>{
        const data = JSON.parse(msg);
        if(data.type==='join'){
            const room = data.room;
            if(!rooms[room]) rooms[room]=[];
            rooms[room].push(ws);

            rooms[room].forEach(client=>{
                if(client.readyState===WebSocket.OPEN)
                    client.send(JSON.stringify({type:'peerList', peers:rooms[room].map((_,i)=>`Peer${i+1}`)}));
            });
            return;
        }
        const room = data.room;
        rooms[room]?.forEach(client=>{
            if(client!==ws && client.readyState===WebSocket.OPEN) client.send(JSON.stringify(data));
        });
    });

    ws.on('close', ()=>{
        for(let room in rooms){
            rooms[room] = rooms[room].filter(client=>client!==ws);
        }
    });
});

console.log("Signaling server running on ws://localhost:3000");
