const roomInput = document.getElementById('roomInput');
const joinBtn = document.getElementById('joinBtn');
const chatContainer = document.getElementById('chatContainer');
const messages = document.getElementById('messages');
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');
const fileInput = document.getElementById('fileInput');
const peerList = document.getElementById('peerList');
const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const toggleVideoBtn = document.getElementById('toggleVideo');
const toggleAudioBtn = document.getElementById('toggleAudio');
const typingIndicator = document.getElementById('typingIndicator');

let ws, localConnection, dataChannel, roomId, localStream, cryptoKey;
let videoEnabled = true, audioEnabled = true;
let typingTimeout;

// Generate AES Key
joinBtn.onclick = async ()=>{
    roomId = roomInput.value.trim();
    if(!roomId) return alert("Enter Room ID");
    document.getElementById('roomContainer').classList.add('hidden');
    chatContainer.classList.remove('hidden');

    cryptoKey = await crypto.subtle.generateKey({name:"AES-GCM", length:256}, true, ["encrypt","decrypt"]);
    await initMedia();
    initWebSocket();
};

async function initMedia(){
    localStream = await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    localVideo.srcObject = localStream;
}

toggleVideoBtn.onclick = ()=>{ videoEnabled=!videoEnabled; localStream.getVideoTracks().forEach(t=>t.enabled=videoEnabled); toggleVideoBtn.textContent=videoEnabled?"Video On":"Video Off"; };
toggleAudioBtn.onclick = ()=>{ audioEnabled=!audioEnabled; localStream.getAudioTracks().forEach(t=>t.enabled=audioEnabled); toggleAudioBtn.textContent=audioEnabled?"Audio On":"Audio Off"; };

function initWebSocket(){
    ws = new WebSocket('ws://localhost:3000');
    ws.onopen = ()=> ws.send(JSON.stringify({type:'join', room:roomId}));
    ws.onmessage = async msg=>{
        const data = JSON.parse(msg.data);
        if(data.type==='offer') await handleOffer(data.offer);
        if(data.type==='answer') await handleAnswer(data.answer);
        if(data.type==='ice') await handleIce(data.candidate);
        if(data.type==='peerList') updatePeerList(data.peers);
        if(data.type==='typing') showTyping();
        if(data.type==='emoji') addEmojiReaction(data.messageId, data.emoji);
    };
    initWebRTC();
}

function initWebRTC(){
    localConnection = new RTCPeerConnection();
    dataChannel = localConnection.createDataChannel("chat");
    dataChannel.onmessage = async e=> await handleIncoming(e.data);
    localConnection.ondatachannel = e=> e.channel.onmessage=async e=> await handleIncoming(e.data);
    localConnection.onicecandidate = e=>{ if(e.candidate) ws.send(JSON.stringify({type:'ice',candidate:e.candidate,room:roomId})); };
    localStream.getTracks().forEach(track=>localConnection.addTrack(track,localStream));
    localConnection.ontrack = e=> remoteVideo.srcObject=e.streams[0];
    createOffer();
}

async function createOffer(){
    const offer = await localConnection.createOffer();
    await localConnection.setLocalDescription(offer);
    ws.send(JSON.stringify({type:'offer', offer, room:roomId}));
}
async function handleOffer(offer){ await localConnection.setRemoteDescription(offer); const answer=await localConnection.createAnswer(); await localConnection.setLocalDescription(answer); ws.send(JSON.stringify({type:'answer', answer, room:roomId})); }
async function handleAnswer(answer){ await localConnection.setRemoteDescription(answer);}
async function handleIce(candidate){ try{ await localConnection.addIceCandidate(candidate);}catch(e){console.error(e);}}

sendBtn.onclick = async ()=>{
    const msg = msgInput.value;
    if(!msg) return;
    const encrypted = await encryptMessage(msg);
    dataChannel.send(encrypted);
    displayMessage('me', msg);
    msgInput.value='';
};

msgInput.addEventListener('input', ()=>{
    ws.send(JSON.stringify({type:'typing', room:roomId}));
    clearTimeout(typingTimeout);
    typingTimeout = setTimeout(()=>{ typingIndicator.classList.add('hidden'); }, 1500);
});

fileInput.onchange = async e=>{
    [...e.target.files].forEach(async file=>{
        const buffer = await file.arrayBuffer();
        const encrypted = await encryptMessage(buffer);
        dataChannel.send(JSON.stringify({file:true,name:file.name,data:Array.from(new Uint8Array(encrypted))}));
        displayFileMessage(file,'me');
    });
};

// Incoming
async function handleIncoming(msg){
    try{
        const obj = JSON.parse(msg);
        if(obj.file){
            const dataArray = new Uint8Array(obj.data);
            const decrypted = await decryptMessage(dataArray.buffer);
            const blob = new Blob([decrypted]);
            displayFileMessage(blob,'peer',obj.name);
        } else if(obj.emoji) {
            addEmojiReaction(obj.messageId,obj.emoji);
        } else {
            const decrypted = await decryptMessage(msg);
            displayMessage('peer', decrypted);
        }
    } catch{
        const decrypted = await decryptMessage(msg);
        displayMessage('peer', decrypted);
    }
}

// Display message
function displayMessage(sender,msg){
    const div=document.createElement('div');
    div.classList.add('message',sender);
    div.dataset.id=Date.now();
    const timestamp = new Date().toLocaleTimeString();
    div.innerHTML=`<span>${msg}</span><div class="timestamp">${timestamp}</div>`;

    const emojiContainer=document.createElement('div'); emojiContainer.classList.add('emoji-container');
    ['👍','❤️','😂','😮'].forEach(emoji=>{
        const span=document.createElement('span'); span.textContent=emoji; span.classList.add('emoji');
        span.onclick=()=>{ ws.send(JSON.stringify({type:'emoji', messageId:div.dataset.id, emoji, room:roomId})); addEmojiReaction(div.dataset.id,emoji); };
        emojiContainer.appendChild(span);
    });
    div.appendChild(emojiContainer);

    messages.appendChild(div);
    messages.scrollTop=messages.scrollHeight;
}

// Add emoji to message
function addEmojiReaction(id,emoji){
    const div=[...messages.children].find(d=>d.dataset.id==id);
    if(!div) return;
    const em=document.createElement('span'); em.textContent=emoji; em.style.marginRight='5px';
    div.querySelector('.emoji-container').appendChild(em);
}

// Typing indicator
function showTyping(){ typingIndicator.classList.remove('hidden'); }

// Files
function displayFileMessage(file,sender='me',name=null){
    const div=document.createElement('div'); div.classList.add('message',sender); div.dataset.id=Date.now();
    const timestamp = new Date().toLocaleTimeString();
    if(file.type.startsWith('image/') || file.type.startsWith('video/')){
        const media=file.type.startsWith('image/')?document.createElement('img'):document.createElement('video');
        media.src=URL.createObjectURL(file); media.controls=true; media.style.maxWidth='200px'; media.style.borderRadius='8px';
        div.appendChild(media);
    } else {
        const link=document.createElement('a'); link.href=URL.createObjectURL(file); link.download=name||'file'; link.textContent=`File: ${name||'unknown'}`; link.classList.add('file-message');
        div.appendChild(link);
    }
    const ts=document.createElement('div'); ts.classList.add('timestamp'); ts.textContent=timestamp;
    div.appendChild(ts);
    messages.appendChild(div); messages.scrollTop=messages.scrollHeight;
}

// Peer list
function updatePeerList(peers){ peerList.innerHTML=''; peers.forEach(p=>{const li=document.createElement('li');li.textContent=p;peerList.appendChild(li);}); }

// Crypto
async function encryptMessage(msg){
    let encoded=(typeof msg==='string')? new TextEncoder().encode(msg):msg;
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},cryptoKey,encoded);
    return JSON.stringify({iv:Array.from(iv),data:Array.from(new Uint8Array(cipher))});
}
async function decryptMessage(msg){ if(typeof msg==='string') msg=JSON.parse(msg); const iv=new Uint8Array(msg.iv); const data=new Uint8Array(msg.data); const decrypted=await crypto.subtle.decrypt({name:'AES-GCM',iv},cryptoKey,data); try{return new TextDecoder().decode(decrypted);}catch{return decrypted;} }
